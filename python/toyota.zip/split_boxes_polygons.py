import csv
import json

input = '/Users/jessicawong/Desktop/split_input.csv'
output = '/Users/jessicawong/Desktop/split_output.csv'
image_url_row_index = 1
anno_row_index = 0
final_array = []

with open(input, 'r', newline='', encoding='utf-8') as (csvfile):
    source = csv.reader(csvfile)
    next(source)

    for row in source:
        if row[anno_row_index] == "" or row[anno_row_index] == "[]":
            continue
        anno = json.loads(row[anno_row_index])['shapes']
        link = row[image_url_row_index]
        if len(anno) < 1:
            continue
        for shape in anno:
            final_array.append([link, json.dumps({"shapes": [shape]})])

with open(output, 'w') as outcsv:
    writer = csv.writer(outcsv)
    writer.writerow(["image_url", "annotation"])
    i = 1
    for n in final_array:
        writer.writerow(n)
        print("Adding Row %s to CSV: " + str(i))
        i += 1
